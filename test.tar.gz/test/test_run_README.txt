# In this example, the reads are from mouse. We will align the reads to mm9 genome (from NCBI or ENSEMBL) and use the provided annotation (Mus_musculus.NCBIM37.67.1_split_exon.gtf)

#1#
perl ../change_fastq_header.pl Unmapped.fasta unmap.fa Truseq_test

#2#
perl ../Truseq_merge_unique_fa.pl UNMAP unmap.fa

#3#
modify SPEC_example.txt (tab-delimited file with two columns):

#4#
perl ../ACF_MAKE.pl SPEC_example.txt testrun.sh

#5#
nohup bash testrun.sh &
